import React from "react";

const SignUp = (props) => {
  return <h1>Sign Up</h1>;
};

export default SignUp;
