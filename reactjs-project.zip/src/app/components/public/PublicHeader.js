import React from "react";
import { withRouter } from "react-router-dom";
const PublicHeader = (props) => {
  return (
    <>
      <header className="header"></header>
    </>
  );
};
export default withRouter(PublicHeader);
