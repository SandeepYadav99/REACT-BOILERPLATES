const createHistory = require("history").createBrowserHistory;

export default createHistory();
