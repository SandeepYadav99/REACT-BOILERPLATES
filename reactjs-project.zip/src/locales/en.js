const en = {
  hello: "hello",
};

export default en;
