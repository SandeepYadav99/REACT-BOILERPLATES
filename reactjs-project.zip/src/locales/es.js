const es = {
  hello: "helloas",
};

export default es;
