// import { GET } from './rest.service';

// export const getProducts = () => {
//   return GET('/products');
// };
