import React from "react";

const Dashboard = (props) => {
  return <h1 className="">Dashboard</h1>;
};

export default Dashboard;
