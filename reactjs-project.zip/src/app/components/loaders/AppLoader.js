import React from "react";

const AppLoader = (props) => (
  <div>
    <h1>Loading</h1>
  </div>
);

export default AppLoader;
