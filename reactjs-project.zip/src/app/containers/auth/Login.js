import React from "react";

const Login = (props) => {
  return <h1>Login</h1>;
};

export default Login;
