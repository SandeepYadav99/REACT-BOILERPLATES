import React from "react";
import { withRouter } from "react-router-dom";
const PublicFooter = () => {
  return <footer></footer>;
};
export default withRouter(PublicFooter);
